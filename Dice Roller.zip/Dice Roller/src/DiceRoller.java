import javax.swing.*;
import java.awt.event.*;

public class DiceRoller {
    public static void main(String args[])
    {
        JFrame frame = new JFrame("Dice Roller");
        frame.setSize(400, 300);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JButton k4 = new JButton("K4");
        k4.setBounds(0, 0, 62, 25);
        frame.getContentPane().add(k4);

        JButton k6 = new JButton("K6");
        k6.setBounds(0,25,62,25);
        frame.getContentPane().add(k6);

        JButton k8 = new JButton("K8");
        k8.setBounds(0,50,62,25);
        frame.getContentPane().add(k8);

        JButton k10 = new JButton("K10");
        k10.setBounds(0,75,62,25);
        frame.getContentPane().add(k10);

        JButton k12 = new JButton("K12");
        k12.setBounds(0,100,62,25);
        frame.getContentPane().add(k12);

        JButton k20 = new JButton("K20");
        k20.setBounds(0,125,62,25);
        frame.getContentPane().add(k20);

        JButton k100 = new JButton("K100");
        k100.setBounds(0,150,62,25);
        frame.getContentPane().add(k100);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(150,200,64,25);
        frame.getContentPane().add(clearButton);

        JTextField listBox = new JTextField("ROLL");
        listBox.setBounds(70,0,70,25);
        frame.getContentPane().add(listBox);

        k4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 4) + 1;
                listBox.setText("K4 = " + a);
            }
        });

        k6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 6) + 1;
                listBox.setText("K6 = " + a);
            }
        });

        k8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 8) + 1;
                listBox.setText("K8 = " + a);
            }
        });

        k10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 10) + 1;
                listBox.setText("K10 = " + a);
            }
        });

        k12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 12) + 1;
                listBox.setText("K12 = " + a);
            }
        });

        k20.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 20) + 1;
                listBox.setText("K20 = " + a);
            }
        });

        k100.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int a;
                a = (int) (Math.random()* 100) + 1;
                listBox.setText("K100 = " + a);
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listBox.setText("");
            }
        });
    }
}
